# Rumbo Futuro · Kit de integración Landing QR

Este paquete es una **base de integración**, no una modificación ya instalada en el repositorio. Se ha preparado a partir del documento funcional y de la estructura pública visible del repositorio (`src/` y `supabase/`). No se han podido inspeccionar los componentes internos, el router, las tablas existentes ni las políticas RLS; por eso no sobrescribe ni presupone esos elementos.

## Contenido

- `src/QRLandingPage.tsx`: landing responsive en React + TypeScript. Recibe el cliente Supabase existente por props y las rutas/imagenes corporativas como configuración.
- `src/qr-analytics.ts`: utilidades UTM y envío de eventos a la Edge Function.
- `src/qr-landing.css`: estilos que heredan variables CSS de la web (`--rf-navy`, `--rf-coral`, etc.). Conecta estos alias con los tokens reales del proyecto.
- `supabase/migrations/202611220001_qr_campaign.sql`: tablas, índices y RLS restrictivas.
- `supabase/functions/*`: funciones Deno para registro, eventos, redirección QR e informe diario.
- `.env.example`: variables requeridas.

## Integración en el repositorio (hacer en una rama)

1. Copia `src/QRLandingPage.tsx`, `src/qr-analytics.ts` y `src/qr-landing.css` dentro de `src/`.
2. En el router actual, añade la ruta hash `#/landing-qr` que renderice `QRLandingPage`. No añadas un enlace al menú público.
3. Pasa a la página el cliente Supabase que ya usa la aplicación (`supabase`), la URL de la función `qr-register`, `qr-event`, la URL principal y la ruta real de formación.
4. Sustituye las rutas de las imágenes por las ubicaciones reales del logo y de los seis retratos originales. Este paquete no contiene esas imágenes porque no estaban adjuntas como archivos.
5. Añade la migración a Supabase después de revisar que no existen tablas con esos nombres. Ejecuta primero en un proyecto de pruebas.
6. Despliega las Edge Functions y configura sus secretos en Supabase.
7. Programa `qr-daily-report` una vez al día con Supabase Cron o un programador externo que invoque la función con `QR_CRON_SECRET`.
8. Integra el panel en el área privada existente, usando la sesión y autorización de administrador que ya tenga el proyecto. No se crea un acceso público al panel en este kit.

## Variables de entorno

Consulta `.env.example`. Las variables `RESEND_API_KEY`, `REPORT_TO`, `QR_CRON_SECRET` y la clave de Supabase con privilegios elevados son **solo del servidor/Edge Functions**. Nunca las pongas en `VITE_*`.

## Configuración visual

El CSS utiliza alias `--rf-*` y fallback neutro. Antes de publicar, enlázalos a los colores y tipografías reales definidos en los estilos actuales. No se han inventado códigos HEX corporativos.

## Importante: consentimiento y RGPD

El texto de privacidad de la página es un marcador que debe completar el responsable del tratamiento (identidad legal, dirección/contacto, finalidad, base jurídica, conservación, derechos y autoridad de control). No publiques el formulario hasta validar ese texto con la persona responsable/asesoría. La casilla de comunicaciones comerciales es independiente y opcional.

La analítica no esencial está condicionada a la aceptación de analítica. La función `qr-redirect` registra el escaneo del QR; revisa con asesoría si esa medición requiere consentimiento previo en vuestro caso y adapta el flujo antes de activarla. La función de registro guarda solo los campos necesarios.

## Límites actuales

- No se ha ejecutado contra vuestro proyecto Supabase real ni se han probado correos.
- No se ha conectado al router ni al panel existentes.
- No se han incluido logo ni retratos, porque el documento los nombra pero no adjunta sus archivos de imagen.
- La identificación de administrador debe vincularse al mecanismo de roles que ya exista en el proyecto. La política SQL incluida deniega el acceso de lectura pública; hay que añadir una política de lectura de administrador basada en vuestro esquema real.
- La entrega de correo requiere verificar el dominio remitente en Resend. Para pruebas puede usarse el remitente de pruebas permitido por Resend, según su configuración vigente.

## Comprobaciones antes de producción

`npm run typecheck` / `npm run build` con los scripts reales del repositorio; prueba de registro; prueba de duplicados; prueba UTM; prueba de redirección; prueba de RLS con usuario anónimo y administrador; prueba de notificación y de informe diario; revisión legal de privacidad/cookies.
