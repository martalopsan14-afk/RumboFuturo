# Notas de integración pendientes

## Router
La ruta pedida es `#/landing-qr`. Hay que añadirla al router/hash routing que ya exista. No se debe crear un segundo `BrowserRouter` ni reemplazar el router global.

## Componente
Ejemplo conceptual de uso (adaptar a imports/rutas reales del proyecto):

```tsx
<QRLandingPage
  supabase={supabase}
  registerEndpoint={`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/qr-register`}
  analyticsEndpoint={`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/qr-event`}
  homeUrl="/"
  trainingUrl="/#/formacion"
  privacyUrl="/#/privacidad"
  logoUrl="/assets/logo-rumbo-futuro.jpeg"
  team={[
    { name: 'Enrique Andrés García Jiménez', role: 'Director de Comunicaciones', image: '/assets/enrique.jpeg' },
    { name: 'Laura Prado Álvarez', role: 'Directora Creativa', image: '/assets/laura-prado.jpeg' },
    { name: 'Laura Gallego Rodríguez', role: 'Web Content Manager', image: '/assets/laura-gallego.jpeg' },
    { name: 'Marta López Sanromán', role: 'Web Developer', image: '/assets/marta.jpeg' },
    { name: 'Adrián Márquez Domínguez', role: 'Community Manager', image: '/assets/adrian.jpeg' },
    { name: 'Mariela Reyes Chaves', role: 'Social Media Designer', image: '/assets/mariela.jpeg' },
  ]}
/>
```

`supabase` se recibe para facilitar el acoplamiento al cliente actual; las operaciones públicas sensibles pasan por Edge Functions y no usan la clave service-role en el navegador.

## Administradores y panel
La migración bloquea lectura directa a `anon` y `authenticated`. Para construir el panel real hay que identificar la tabla/claim de roles del proyecto y añadir una política `SELECT` limitada a administradores. No se debe basar la seguridad únicamente en ocultar una ruta React.

## Campañas QR
Crear una fila en `qr_campaigns` por campaña, por ejemplo `rumbo-futuro-general`, con su destino URL. Imprimir como QR la URL pública de la función `qr-redirect?campaign=rumbo-futuro-general`. La URL de destino se podrá cambiar en la tabla sin reimprimir el QR.

## Informe diario
Configurar un cron que haga POST a `/functions/v1/qr-daily-report` con header `x-qr-cron-secret`. Definir una zona horaria y una hora de envío explícitas. La comparación incluida es una ventana móvil de 24 horas frente a las 24 horas anteriores; el informe se etiqueta con fecha UTC por defecto. Ajustar a Europe/Madrid si esa es la convención de negocio.
