export type UTM = {
  utm_source: string | null;
  utm_medium: string | null;
  utm_campaign: string | null;
};

const UTM_KEYS = ['utm_source', 'utm_medium', 'utm_campaign'] as const;

export function readCampaignParams(search = window.location.search): UTM {
  const params = new URLSearchParams(search);
  return {
    utm_source: params.get('utm_source'),
    utm_medium: params.get('utm_medium'),
    utm_campaign: params.get('utm_campaign'),
  };
}

export function campaignIdFromUrl(search = window.location.search): string {
  const params = new URLSearchParams(search);
  return params.get('utm_campaign') || 'rumbo-futuro-general';
}

export function hasAnalyticsConsent(): boolean {
  return window.localStorage.getItem('rf-analytics-consent') === 'accepted';
}

export function saveAnalyticsConsent(accepted: boolean): void {
  window.localStorage.setItem('rf-analytics-consent', accepted ? 'accepted' : 'rejected');
}

export async function trackQrEvent(
  endpoint: string,
  event: 'landing_view' | 'main_site_click' | 'training_click',
  extra: Record<string, unknown> = {},
): Promise<void> {
  if (!hasAnalyticsConsent()) return;
  const payload = {
    event,
    campaign_id: campaignIdFromUrl(),
    utm: readCampaignParams(),
    path: window.location.hash || '/',
    ...extra,
  };
  try {
    await fetch(endpoint, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
      keepalive: true,
    });
  } catch {
    // La analítica no debe bloquear la navegación del visitante.
  }
}

export function appendUtmToUrl(destination: string): string {
  const target = new URL(destination, window.location.origin);
  const current = new URLSearchParams(window.location.search);
  for (const key of UTM_KEYS) {
    const value = current.get(key);
    if (value && !target.searchParams.has(key)) target.searchParams.set(key, value);
  }
  return target.toString();
}
