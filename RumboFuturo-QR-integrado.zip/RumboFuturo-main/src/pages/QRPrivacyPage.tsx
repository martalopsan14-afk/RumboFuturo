import { LEGAL_DOCUMENTS } from '@/data/legal';

export function QRPrivacyPage() {
  const document = LEGAL_DOCUMENTS.find(item => item.id === 'politica-privacidad');
  return <main className="min-h-screen bg-ivory px-5 py-12 text-graphite"><article className="mx-auto max-w-3xl rounded-2xl bg-white p-6 shadow-sm sm:p-10"><a href="/#/landing-qr" className="text-sm font-semibold text-ink underline">Volver a Rumbo Futuro</a><h1 className="mt-6 text-3xl">Política de privacidad</h1><div role="alert" className="my-6 rounded-xl border border-amber-300 bg-amber-50 p-4 text-sm text-amber-950"><strong>Documento pendiente de completar.</strong> El texto facilitado al proyecto contiene campos de ejemplo y datos sin sustituir. No debe considerarse una política final ni utilizarse para captar datos hasta que el responsable lo complete y valide.</div><div className="whitespace-pre-wrap text-sm leading-7">{document?.body ?? 'No se ha encontrado el texto de privacidad.'}</div></article></main>;
}
