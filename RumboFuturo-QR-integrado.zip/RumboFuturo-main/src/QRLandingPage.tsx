import { FormEvent, useEffect, useMemo, useState } from 'react';
import type { SupabaseClient } from '@supabase/supabase-js';
import { appendUtmToUrl, campaignIdFromUrl, hasAnalyticsConsent, readCampaignParams, saveAnalyticsConsent, trackQrEvent } from './qr-analytics';
import './qr-landing.css';

type TeamMember = { name: string; role: string; image: string };
type Props = {
  supabase: SupabaseClient;
  registerEndpoint: string;
  analyticsEndpoint: string;
  homeUrl: string;
  trainingUrl: string;
  privacyUrl: string;
  logoUrl: string;
  team: TeamMember[];
};

export function QRLandingPage(props: Props) {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [privacyAccepted, setPrivacyAccepted] = useState(false);
  const [marketingAccepted, setMarketingAccepted] = useState(false);
  const [analyticsAccepted, setAnalyticsAccepted] = useState(hasAnalyticsConsent());
  const [status, setStatus] = useState<'idle' | 'sending' | 'success' | 'error'>('idle');
  const campaignId = useMemo(() => campaignIdFromUrl(), []);

  useEffect(() => {
    if (analyticsAccepted) void trackQrEvent(props.analyticsEndpoint, 'landing_view');
  }, [analyticsAccepted, props.analyticsEndpoint]);

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!privacyAccepted || status === 'sending') return;
    setStatus('sending');
    try {
      const response = await fetch(props.registerEndpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          full_name: name.trim(),
          email: email.trim().toLowerCase(),
          privacy_accepted: privacyAccepted,
          marketing_accepted: marketingAccepted,
          campaign_id: campaignId,
          utm: readCampaignParams(),
        }),
      });
      if (!response.ok) throw new Error('No se pudo completar el registro');
      setStatus('success');
    } catch {
      setStatus('error');
    }
  }

  function consentAnalytics(accepted: boolean) {
    saveAnalyticsConsent(accepted);
    setAnalyticsAccepted(accepted);
    if (accepted) void trackQrEvent(props.analyticsEndpoint, 'landing_view');
  }

  return (
    <main className="rf-qr">
      <header className="rf-qr__hero" id="inicio">
        <img className="rf-qr__logo" src={props.logoUrl} alt="Rumbo Futuro" />
        <div className="rf-qr__intro">
          <p className="rf-eyebrow">Talento periodístico · Nuevas oportunidades</p>
          <h1>¡Bienvenido a Rumbo Futuro!</h1>
          <p>Queremos conocerte. Déjanos tus datos y descubre un proyecto que conecta el talento periodístico con nuevas oportunidades.</p>
        </div>
        <form className="rf-form" onSubmit={submit}>
          <label>Nombre y apellidos<input required minLength={2} autoComplete="name" value={name} onChange={e => setName(e.target.value)} /></label>
          <label>Correo electrónico<input required type="email" autoComplete="email" value={email} onChange={e => setEmail(e.target.value)} /></label>
          <label className="rf-check"><input type="checkbox" required checked={privacyAccepted} onChange={e => setPrivacyAccepted(e.target.checked)} />
            He leído y acepto la <a href={props.privacyUrl} target="_blank" rel="noreferrer">política de privacidad</a> y el tratamiento de mis datos para gestionar este registro.
          </label>
          <label className="rf-check"><input type="checkbox" checked={marketingAccepted} onChange={e => setMarketingAccepted(e.target.checked)} />
            Quiero recibir comunicaciones comerciales de Rumbo Futuro (opcional).
          </label>
          <button type="submit" disabled={status === 'sending'}>{status === 'sending' ? 'ENVIANDO…' : 'QUIERO CONOCER RUMBO FUTURO'}</button>
          {status === 'success' && <p role="status" className="rf-success">¡Gracias! Tu registro se ha realizado correctamente.</p>}
          {status === 'error' && <p role="alert" className="rf-error">No hemos podido completar el registro. Inténtalo de nuevo.</p>}
          <small>El registro no es obligatorio para continuar navegando por la web.</small>
        </form>
      </header>

      <section className="rf-section" id="quienes-somos"><p className="rf-eyebrow">Quiénes somos</p><h2>¿Y ahora qué?</h2>
        <p>Rumbo Futuro nace para conectar el talento periodístico emergente con el mundo profesional, acercando la formación práctica, el conocimiento especializado y nuevas oportunidades de desarrollo.</p>
      </section>
      <section className="rf-section rf-section--accent" id="propuesta"><p className="rf-eyebrow">Nuestra propuesta de valor</p>
        <h2>Aprender haciendo. Conectar para avanzar.</h2>
        <p>Ofrecemos una formación práctica y flexible geográficamente que conecta a los periodistas emergentes con investigadores y expertos, a un precio competitivo.</p>
        <div className="rf-pillars"><article><h3>Formación práctica</h3><p>Aprendizaje orientado a los retos reales del periodismo.</p></article><article><h3>Flexibilidad geográfica</h3><p>Acceso a la formación sin barreras de ubicación.</p></article><article><h3>Expertos e investigadores</h3><p>Conocimiento especializado y conexiones profesionales.</p></article><article><h3>Precio competitivo</h3><p>Una alternativa formativa accesible.</p></article></div>
      </section>
      <section className="rf-section" id="esencia"><p className="rf-eyebrow">Nuestra esencia</p><h2>Creemos en lo que viene.</h2>
        <ul className="rf-values"><li>Creemos en el talento joven.</li><li>Apostamos por el aprendizaje práctico.</li><li>Acercamos el conocimiento especializado al periodismo emergente.</li><li>Conectamos formación y experiencia profesional.</li><li>Trabajamos para generar nuevas oportunidades.</li></ul>
      </section>
      <section className="rf-section" id="equipo"><p className="rf-eyebrow">Las personas detrás del proyecto</p><h2>Conoce a nuestro equipo</h2>
        <div className="rf-team">{props.team.map(member => <article className="rf-person" key={member.name}><img src={member.image} alt={member.name} loading="lazy" /><h3>{member.name}</h3><p>{member.role}</p></article>)}</div>
      </section>
      <section className="rf-cta"><h2>El futuro del periodismo se construye creando oportunidades.</h2><p>Ahora que ya conoces nuestra esencia, te invitamos a descubrir todo lo que hacemos en Rumbo Futuro.</p>
        <a className="rf-button" href={appendUtmToUrl(props.homeUrl)} onClick={() => void trackQrEvent(props.analyticsEndpoint, 'main_site_click')}>ENTRAR EN NUESTRA WEB</a>
        <a className="rf-secondary" href={appendUtmToUrl(props.trainingUrl)} onClick={() => void trackQrEvent(props.analyticsEndpoint, 'training_click')}>DESCUBRE NUESTRA FORMACIÓN</a>
      </section>
      <footer className="rf-footer"><a href={props.privacyUrl}>Privacidad</a><button type="button" className="rf-consent-link" onClick={() => consentAnalytics(!analyticsAccepted)}>{analyticsAccepted ? 'Desactivar analítica' : 'Aceptar analítica'}</button></footer>
    </main>
  );
}
