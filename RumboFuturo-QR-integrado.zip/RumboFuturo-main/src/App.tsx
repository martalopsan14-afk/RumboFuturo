import { useEffect, type ComponentType } from 'react';
import { SiteFooter } from '@/components/layout/SiteFooter';
import { SiteHeader } from '@/components/layout/SiteHeader';
import { HomePage } from '@/pages/HomePage';
import { RumboPage } from '@/pages/RumboPage';
import { TrabajoPage } from '@/pages/TrabajoPage';
import { FormacionPage } from '@/pages/FormacionPage';
import { ColaboradoresPage } from '@/pages/ColaboradoresPage';
import { SaberMasPage } from '@/pages/SaberMasPage';
import { RumboChatPage } from '@/pages/RumboChatPage';
import { AdminPage } from '@/pages/AdminPage';
import { useHashRoute } from '@/hooks/useHashRoute';
import type { PageId } from '@/data/navigation';
import { QRLandingPage } from '@/QRLandingPage';
import { QRPrivacyPage } from '@/pages/QRPrivacyPage';
import { supabase } from '@/lib/supabase';

const PAGE_COMPONENTS: Record<PageId, ComponentType> = {
  inicio: HomePage,
  'nuestro-rumbo': RumboPage,
  'nuestro-trabajo': TrabajoPage,
  'formacion-dual': FormacionPage,
  colaboradores: ColaboradoresPage,
  'saber-mas': SaberMasPage,
  rumbochat: RumboChatPage,
};

export default function App() {
  const route = useHashRoute();

  useEffect(() => {
    if (route.type !== 'page' || !route.anchor) {
      if (route.type === 'page') window.scrollTo({ top: 0, behavior: 'auto' });
      return;
    }
    const target = document.getElementById(route.anchor);
    target?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }, [route]);

  // Admin route: render standalone, no public header/footer
  if (route.type === 'admin') {
    return <AdminPage />;
  }

  if (route.type === 'qr-privacy') {
    return <QRPrivacyPage />;
  }

  if (route.type === 'qr-landing') {
    const base = import.meta.env.VITE_SUPABASE_URL;
    return (
      <QRLandingPage
        supabase={supabase}
        registerEndpoint={`${base}/functions/v1/qr-register`}
        analyticsEndpoint={`${base}/functions/v1/qr-event`}
        homeUrl={`${window.location.origin}/#/inicio`}
        trainingUrl={`${window.location.origin}/#/formacion-dual`}
        privacyUrl={`${window.location.origin}/#/privacidad-qr`}
        logoUrl="/Logo_normal.jpeg"
        team={[
          { name: 'Enrique Andrés Jiménez', role: 'Equipo Rumbo Futuro', image: '/assets/team/Enrique_Andres_Jimenez.jpeg' },
          { name: 'Laura Prado', role: 'Equipo Rumbo Futuro', image: '/assets/team/Laura_Prado.jpeg' },
          { name: 'Laura Gallego', role: 'Equipo Rumbo Futuro', image: '/assets/team/Laura_Gallego.jpeg' },
          { name: 'Marta López', role: 'Equipo Rumbo Futuro', image: '/assets/team/Marta_Lopez.jpeg' },
          { name: 'Adrián Márquez', role: 'Equipo Rumbo Futuro', image: '/assets/team/Adrian_Marquez.jpeg' },
          { name: 'Mariela Reyes', role: 'Equipo Rumbo Futuro', image: '/assets/team/Mariela_Reyes.jpeg' },
        ]}
      />
    );
  }

  const PageComponent = PAGE_COMPONENTS[route.page];

  return (
    <div className="flex min-h-screen flex-col bg-ivory font-body text-graphite">
      <SiteHeader activePage={route.page} />
      <main className="flex-1">
        <PageComponent />
      </main>
      <SiteFooter />
    </div>
  );
}
