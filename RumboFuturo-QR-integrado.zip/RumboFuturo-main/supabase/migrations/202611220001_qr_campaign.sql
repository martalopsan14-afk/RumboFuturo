-- Ejecutar solo después de revisar el esquema actual y en entorno de pruebas.
create table if not exists public.qr_campaigns (
  id text primary key,
  name text not null,
  destination_url text not null,
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.qr_leads (
  id uuid primary key default gen_random_uuid(),
  full_name text not null check (char_length(full_name) between 2 and 180),
  email text not null,
  campaign_id text references public.qr_campaigns(id) on update cascade on delete set null,
  utm_source text,
  utm_medium text,
  utm_campaign text,
  privacy_accepted_at timestamptz not null,
  marketing_accepted_at timestamptz,
  created_at timestamptz not null default now(),
  constraint qr_leads_email_campaign_unique unique (email, campaign_id)
);
create index if not exists qr_leads_created_at_idx on public.qr_leads(created_at desc);

create table if not exists public.qr_events (
  id uuid primary key default gen_random_uuid(),
  event_type text not null check (event_type in ('qr_scan','landing_view','main_site_click','training_click')),
  campaign_id text references public.qr_campaigns(id) on update cascade on delete set null,
  utm_source text,
  utm_medium text,
  utm_campaign text,
  session_id text,
  created_at timestamptz not null default now()
);
create index if not exists qr_events_created_type_idx on public.qr_events(created_at desc,event_type);
create index if not exists qr_events_campaign_idx on public.qr_events(campaign_id,created_at desc);

create table if not exists public.qr_report_runs (
  report_date date primary key,
  sent_at timestamptz not null default now()
);

alter table public.qr_campaigns enable row level security;
alter table public.qr_leads enable row level security;
alter table public.qr_events enable row level security;
alter table public.qr_report_runs enable row level security;

-- No se concede lectura pública ni escritura directa desde el navegador.
revoke all on public.qr_campaigns, public.qr_leads, public.qr_events, public.qr_report_runs from anon, authenticated;
grant all on public.qr_campaigns, public.qr_leads, public.qr_events, public.qr_report_runs to service_role;

-- Añadir una política SELECT para administradores solo después de identificar
-- el esquema real de roles/perfiles del proyecto. No se presupone aquí.

-- Campaña inicial para que el primer QR pueda utilizarse tras aplicar la migración.
insert into public.qr_campaigns (id, name, destination_url, active)
values ('rumbo-futuro-general', 'Rumbo Futuro · General', 'https://TU-DOMINIO/#/landing-qr', false)
on conflict (id) do nothing;
