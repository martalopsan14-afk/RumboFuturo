import { createClient } from 'npm:@supabase/supabase-js@2';
const corsHeaders = { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Methods': 'GET, POST, PATCH, OPTIONS', 'Access-Control-Allow-Headers': 'Content-Type, Authorization, Apikey, X-Client-Info' };
const json = (body: unknown, status = 200) => new Response(JSON.stringify(body), { status, headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
function decode(value: string) { const raw = atob(value.replace(/-/g, '+').replace(/_/g, '/') + '='.repeat((4 - value.length % 4) % 4)); return Uint8Array.from(raw, c => c.charCodeAt(0)); }
async function isAdmin(token: string) {
  try {
    const secret = Deno.env.get('RUMBO_JWT_SECRET'); if (!secret) return false;
    const [h, p, sig] = token.split('.'); if (!h || !p || !sig) return false;
    const header = JSON.parse(new TextDecoder().decode(decode(h)));
    const payload = JSON.parse(new TextDecoder().decode(decode(p)));
    if (header.alg !== 'HS256' || header.typ !== 'JWT' || payload.role !== 'rumbo-admin' || payload.username !== 'rumbofuturoo' || typeof payload.exp !== 'number' || Date.now() >= payload.exp * 1000) return false;
    const key = await crypto.subtle.importKey('raw', new TextEncoder().encode(secret), { name: 'HMAC', hash: 'SHA-256' }, false, ['verify']);
    return crypto.subtle.verify('HMAC', key, decode(sig), new TextEncoder().encode(`${h}.${p}`));
  } catch { return false; }
}
Deno.serve(async req => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  const token = req.headers.get('Authorization')?.replace(/^Bearer\s+/i, '') ?? '';
  if (!(await isAdmin(token))) return json({ error: 'No autorizado' }, 401);
  const url = Deno.env.get('SUPABASE_URL'); const key = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
  if (!url || !key) return json({ error: 'Configuración incompleta' }, 500);
  const db = createClient(url, key);
  if (req.method === 'POST') {
    const body = await req.json();
    const id = String(body.id ?? '').toLowerCase().replace(/[^a-z0-9-]/g, '-').slice(0, 60);
    const name = String(body.name ?? '').trim().slice(0, 120);
    const destination_url = String(body.destination_url ?? '').trim();
    try { const parsed = new URL(destination_url); if (!['https:', 'http:'].includes(parsed.protocol)) throw new Error(); } catch { return json({ error: 'La URL de destino no es válida' }, 400); }
    if (!id || !name) return json({ error: 'Identificador y nombre son obligatorios' }, 400);
    const { data, error } = await db.from('qr_campaigns').insert({ id, name, destination_url, active: true }).select().single();
    if (error) return json({ error: error.code === '23505' ? 'Ya existe una campaña con ese identificador' : 'No se pudo crear la campaña' }, 400);
    return json({ campaign: data }, 201);
  }
  if (req.method === 'PATCH') {
    const body = await req.json();
    const id = String(body.id ?? '').slice(0, 60);
    const update: Record<string, unknown> = {};
    if (typeof body.active === 'boolean') update.active = body.active;
    if (typeof body.destination_url === 'string') {
      try { const parsed = new URL(body.destination_url); if (!['https:', 'http:'].includes(parsed.protocol)) throw new Error(); update.destination_url = body.destination_url; }
      catch { return json({ error: 'La URL de destino no es válida' }, 400); }
    }
    if (!id || Object.keys(update).length === 0) return json({ error: 'No hay cambios válidos' }, 400);
    const { data, error } = await db.from('qr_campaigns').update(update).eq('id', id).select().single();
    if (error) return json({ error: 'No se pudo actualizar la campaña' }, 400);
    return json({ campaign: data });
  }
  if (req.method !== 'GET') return json({ error: 'Método no permitido' }, 405);
  const [campaigns, events, leads, leadTotal] = await Promise.all([
    db.from('qr_campaigns').select('id,name,destination_url,active,created_at').order('created_at', { ascending: false }),
    db.from('qr_events').select('event_type,campaign_id,created_at').gte('created_at', new Date(Date.now() - 30 * 86400000).toISOString()),
    db.from('qr_leads').select('id,full_name,email,campaign_id,created_at,marketing_accepted_at').order('created_at', { ascending: false }).limit(500),
    db.from('qr_leads').select('id', { count: 'exact', head: true }),
  ]);
  if (campaigns.error || events.error || leads.error || leadTotal.error) return json({ error: 'No se pudieron cargar las estadísticas. Comprueba que la migración QR está aplicada.' }, 500);
  const leadCounts: Record<string, number> = {};
  await Promise.all((campaigns.data ?? []).map(async campaign => {
    const result = await db.from('qr_leads').select('id', { count: 'exact', head: true }).eq('campaign_id', campaign.id);
    leadCounts[campaign.id] = result.count ?? 0;
  }));
  return json({ campaigns: campaigns.data ?? [], events: events.data ?? [], leads: leads.data ?? [], leadTotal: leadTotal.count ?? 0, leadCounts });
});
