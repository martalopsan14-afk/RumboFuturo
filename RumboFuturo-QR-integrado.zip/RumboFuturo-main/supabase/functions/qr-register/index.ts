import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
import { corsHeaders } from '../_shared/cors.ts';

const json = (body: unknown, status = 200) => new Response(JSON.stringify(body), { status, headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  if (req.method !== 'POST') return json({ error: 'Method not allowed' }, 405);
  try {
    const body = await req.json();
    const full_name = String(body.full_name ?? '').trim();
    const email = String(body.email ?? '').trim().toLowerCase();
    if (full_name.length < 2 || full_name.length > 180 || !emailPattern.test(email) || body.privacy_accepted !== true) return json({ error: 'Datos no válidos' }, 400);
    const supabase = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!);
    const utm = body.utm ?? {};
    const campaign_id = String(body.campaign_id ?? 'rumbo-futuro-general').slice(0, 120);
    const { data, error } = await supabase.from('qr_leads').upsert({
      full_name, email, campaign_id,
      utm_source: typeof utm.utm_source === 'string' ? utm.utm_source.slice(0, 200) : null,
      utm_medium: typeof utm.utm_medium === 'string' ? utm.utm_medium.slice(0, 200) : null,
      utm_campaign: typeof utm.utm_campaign === 'string' ? utm.utm_campaign.slice(0, 200) : null,
      privacy_accepted_at: new Date().toISOString(),
      marketing_accepted_at: body.marketing_accepted === true ? new Date().toISOString() : null,
    }, { onConflict: 'email,campaign_id', ignoreDuplicates: true }).select('id').maybeSingle();
    if (error) throw error;

    // Email notification contains no personal data. Failure is logged but does not undo registration.
    const resendKey = Deno.env.get('RESEND_API_KEY');
    if (data && resendKey && Deno.env.get('REPORT_FROM')) {
      const result = await fetch('https://api.resend.com/emails', {
        method: 'POST', headers: { Authorization: `Bearer ${resendKey}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({ from: Deno.env.get('REPORT_FROM'), to: [Deno.env.get('REPORT_TO') ?? 'rumbofuturoo@gmail.com'], subject: 'Nuevo registro en Rumbo Futuro', html: '<p>Se ha recibido un nuevo registro QR.</p><p>Consulta los datos desde el panel privado de Rumbo Futuro.</p>' }),
      });
      if (!result.ok) console.error('Resend notification failed', await result.text());
    }
    return json({ ok: true, duplicate: !data });
  } catch (error) {
    console.error(error);
    return json({ error: 'No se pudo procesar el registro' }, 500);
  }
});
