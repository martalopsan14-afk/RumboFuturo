import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
const json = (body: unknown, status = 200) => new Response(JSON.stringify(body), { status, headers: { 'Content-Type': 'application/json' } });
Deno.serve(async (req) => {
  if (req.headers.get('x-qr-cron-secret') !== Deno.env.get('QR_CRON_SECRET')) return json({ error: 'Unauthorized' }, 401);
  const supabase = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!);
  const now = new Date();
  const today = now.toISOString().slice(0, 10);
  const start = new Date(now.getTime() - 24 * 60 * 60 * 1000).toISOString();
  const yesterdayStart = new Date(now.getTime() - 48 * 60 * 60 * 1000).toISOString();
  const { data: already } = await supabase.from('qr_report_runs').select('report_date').eq('report_date', today).maybeSingle();
  if (already) return json({ ok: true, skipped: 'already_sent' });
  const count = async (table: 'qr_events' | 'qr_leads', type?: string, from = start, to = now.toISOString()) => {
    let q = supabase.from(table).select('id', { count: 'exact', head: true }).gte('created_at', from).lt('created_at', to);
    if (type) q = q.eq('event_type', type);
    const { count: n, error } = await q; if (error) throw error; return n ?? 0;
  };
  try {
    const [scans, views, leads, mainClicks, yScans, yViews, yLeads, yClicks, totalScans, totalViews, totalLeads, totalClicks] = await Promise.all([
      count('qr_events','qr_scan'), count('qr_events','landing_view'), count('qr_leads'), count('qr_events','main_site_click'),
      count('qr_events','qr_scan',yesterdayStart,start), count('qr_events','landing_view',yesterdayStart,start), count('qr_leads',undefined,yesterdayStart,start), count('qr_events','main_site_click',yesterdayStart,start),
      count('qr_events','qr_scan','1970-01-01T00:00:00.000Z'), count('qr_events','landing_view','1970-01-01T00:00:00.000Z'), count('qr_leads',undefined,'1970-01-01T00:00:00.000Z'), count('qr_events','main_site_click','1970-01-01T00:00:00.000Z'),
    ]);
    const pct = (a:number,b:number) => b ? `${(a/b*100).toFixed(1)}%` : '— (sin denominador)';
    const lines = [
      `Últimas 24 h: escaneos ${scans}; visitas landing ${views}; registros ${leads}; clics web ${mainClicks}.`,
      `Conversión escaneo→visita: ${pct(views,scans)}; visita→registro: ${pct(leads,views)}; registro→clic web: ${pct(mainClicks,leads)}; escaneo→registro: ${pct(leads,scans)}.`,
      `Día anterior (ventana móvil): escaneos ${yScans}; visitas ${yViews}; registros ${yLeads}; clics ${yClicks}.`,
      `Acumulado: escaneos ${totalScans}; visitas ${totalViews}; registros ${totalLeads}; clics ${totalClicks}.`,
    ];
    const sent = await fetch('https://api.resend.com/emails', { method:'POST', headers:{ Authorization:`Bearer ${Deno.env.get('RESEND_API_KEY')}`, 'Content-Type':'application/json' }, body:JSON.stringify({ from:Deno.env.get('REPORT_FROM'), to:[Deno.env.get('REPORT_TO') ?? 'rumbofuturoo@gmail.com'], subject:`Informe diario QR Rumbo Futuro · ${today}`, text:lines.join('\n\n') }) });
    if (!sent.ok) throw new Error(`Resend: ${await sent.text()}`);
    const { error: markError } = await supabase.from('qr_report_runs').insert({ report_date: today });
    if (markError) throw markError;
    return json({ ok:true, report_date:today, metrics:{scans,views,leads,mainClicks} });
  } catch (error) { console.error(error); return json({ error:'No se pudo enviar el informe' },500); }
});
