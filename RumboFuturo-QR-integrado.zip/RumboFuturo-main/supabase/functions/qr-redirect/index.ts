import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
Deno.serve(async (req) => {
  const url = new URL(req.url);
  const campaign = url.searchParams.get('campaign') ?? 'rumbo-futuro-general';
  const supabase = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!);
  const { data } = await supabase.from('qr_campaigns').select('destination_url,active').eq('id', campaign).maybeSingle();
  const destination = data?.active && data.destination_url ? new URL(data.destination_url) : new URL(Deno.env.get('PUBLIC_SITE_URL')! + (Deno.env.get('QR_LANDING_PATH') ?? '/#/landing-qr'));
  if (data?.active) {
    const utm = ['utm_source','utm_medium','utm_campaign'];
    for (const key of utm) { const value = url.searchParams.get(key); if (value) destination.searchParams.set(key, value); }
  }
  const { error } = await supabase.from('qr_events').insert({ event_type: 'qr_scan', campaign_id: campaign, utm_source: url.searchParams.get('utm_source') ?? 'qr', utm_medium: url.searchParams.get('utm_medium') ?? 'offline', utm_campaign: url.searchParams.get('utm_campaign') ?? campaign });
  if (error) console.error('QR scan event could not be saved', error);
  return Response.redirect(destination.toString(), 302);
});
