import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
import { corsHeaders } from '../_shared/cors.ts';
const json = (body: unknown, status = 200) => new Response(JSON.stringify(body), { status, headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  if (req.method !== 'POST') return json({ error: 'Method not allowed' }, 405);
  try {
    const body = await req.json();
    const allowed = new Set(['landing_view', 'main_site_click', 'training_click']);
    if (!allowed.has(body.event)) return json({ error: 'Evento no permitido' }, 400);
    const utm = body.utm ?? {};
    const supabase = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!);
    const { error } = await supabase.from('qr_events').insert({
      event_type: body.event,
      campaign_id: String(body.campaign_id ?? 'rumbo-futuro-general').slice(0, 120),
      utm_source: typeof utm.utm_source === 'string' ? utm.utm_source.slice(0, 200) : null,
      utm_medium: typeof utm.utm_medium === 'string' ? utm.utm_medium.slice(0, 200) : null,
      utm_campaign: typeof utm.utm_campaign === 'string' ? utm.utm_campaign.slice(0, 200) : null,
      session_id: typeof body.session_id === 'string' ? body.session_id.slice(0, 80) : null,
    });
    if (error) throw error;
    return json({ ok: true });
  } catch (error) { console.error(error); return json({ error: 'No se pudo registrar el evento' }, 500); }
});
