# Rumbo Futuro · Landing QR y analítica

Se ha integrado la landing `/#/landing-qr` y una pestaña **Campañas QR** dentro del panel privado `/#/admin`.

## Incluido en este cambio

- Landing responsive conectada a las Edge Functions `qr-register` y `qr-event`.
- Uso del logotipo y las seis fotografías existentes en `public/assets/team/`.
- Registro de escaneos QR, visitas consentidas, clics a la web/formación y formularios.
- Migración SQL con campañas, leads, eventos y ejecuciones de informes.
- Funciones `qr-register`, `qr-event`, `qr-redirect`, `qr-daily-report` y `qr-admin`.
- Panel privado con métricas de los últimos 30 días, lista de campañas, generador de campañas, QR descargable y tabla de contactos.
- El endpoint administrativo valida el JWT de administración con `RUMBO_JWT_SECRET`; no expone la service-role key al navegador.

## Configuración necesaria antes de desplegar

1. Crear una copia de seguridad y aplicar `supabase/migrations/202611220001_qr_campaign.sql` en Supabase.
2. Configurar en el frontend `.env`:

   ```env
   VITE_SUPABASE_URL=https://TU-PROYECTO.supabase.co
   VITE_SUPABASE_ANON_KEY=TU_ANON_KEY
   ```

3. Configurar como secretos de Supabase (nunca como variables `VITE_`):

   ```bash
   supabase secrets set RUMBO_JWT_SECRET="EL_MISMO_SECRETO_QUE_USA_ADMIN_AUTH"
   supabase secrets set PUBLIC_SITE_URL="https://TU-DOMINIO-PUBLICO"
   supabase secrets set QR_LANDING_PATH="/#/landing-qr"
   supabase secrets set RESEND_API_KEY="re_..."
   supabase secrets set REPORT_TO="rumbofuturoo@gmail.com"
   supabase secrets set REPORT_FROM="Rumbo Futuro <informes@TU-DOMINIO-VERIFICADO>"
   supabase secrets set QR_CRON_SECRET="UN_SECRETO_LARGO_Y_ALEATORIO"
   ```

   `RUMBO_JWT_SECRET` debe coincidir exactamente con el secreto ya usado por `admin-auth`. No lo cambies sin planificar la rotación porque invalidaría los tokens administrativos existentes.

4. Desplegar las funciones:

   ```bash
   supabase functions deploy qr-register --no-verify-jwt
   supabase functions deploy qr-event --no-verify-jwt
   supabase functions deploy qr-redirect --no-verify-jwt
   supabase functions deploy qr-admin --no-verify-jwt
   supabase functions deploy qr-daily-report --no-verify-jwt
   ```

5. En el panel privado, entrar en **Campañas QR** y crear campañas. La migración inserta `rumbo-futuro-general` inactiva para evitar redirigir a un dominio ficticio. Al crear nuevas campañas, el destino por defecto es `/#/landing-qr` del dominio en que se esté usando el panel.
6. Para informes diarios, programar una llamada POST a `https://TU-PROYECTO.supabase.co/functions/v1/qr-daily-report` con cabecera `x-qr-cron-secret: <QR_CRON_SECRET>`. Configurarla a la hora deseada y zona `Europe/Madrid` en el programador.

## Pendientes de producción (bloqueantes)

- **Privacidad:** `src/data/legal-content.txt` contiene marcadores como “El titular del sitio”, “XX España” y enlaces de ejemplo. La landing enlaza temporalmente a la página de inicio porque la política no está publicada como página independiente. No captar datos reales hasta completar y validar responsable, contacto, finalidades, base jurídica, conservación, derechos y política de cookies.
- **Analítica y cookies:** revisar jurídicamente si el registro del escaneo en `qr-redirect` requiere consentimiento previo. La landing solo registra `landing_view` y clics cuando hay consentimiento, pero el escaneo se registra en el servidor al resolver el QR.
- **Correo:** verificar el dominio remitente en Resend y probar notificaciones e informes.
- **Dominio:** sustituir `TU-DOMINIO` en la fila inicial de la migración si se desea activarla manualmente. Mantenerla inactiva hasta comprobar la URL real.
- **QR externo:** las imágenes QR se generan usando `api.qrserver.com`; el contenido del QR es la URL de redirección pública. Si se prefiere generación local, habrá que añadir una librería QR al proyecto.
- **Pruebas:** probar registro nuevo y duplicado, UTM, lectura/escaneo, panel con token válido e inválido, RLS, notificación y cron en staging antes de producción.

## Comprobaciones

El entorno de esta entrega no tenía `node_modules` instalados y la instalación de dependencias agotó el tiempo disponible; por tanto no se pudo confirmar `npm run typecheck` ni `npm run build`. Ejecutar ambos en el entorno del proyecto antes de desplegar.
